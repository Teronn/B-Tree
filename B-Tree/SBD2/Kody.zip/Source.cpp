#include <iostream>
#include <vector>
#include <stdlib.h>

#include <cstdlib>
#include <ctime>
#include "Page.h"
#include "Operations.h"
#pragma once


using namespace std;

int main() {

	Operations oper;
	Page* page = new Page;
	int table[5] = { 3,4,5,6,7 };
	int c = 0;

	// eksperyment nr.1

	double tablica[10000];
	ofstream wynik("C:/Users/SYLWESTER/source/repos/SBD2/SBD2/wynik.txt");

	for (int i = 0; i < 10000; )
	{
		c = rand() % 50000 + 1;
		if (oper.keyExists(c) == false) {
			oper.loadBlocks(oper.height, c, page);
			oper.addRecord(c, page, table, oper.height, 0);
			oper.loadInfo();
			tablica[i] = (double)i;
			tablica[i] = (double)(tablica[i] / (2 * oper.level*oper.address_dist));
			i++;
			wynik << tablica[i] << " ";

		}
		
	}

	wynik.close();
	

	delete page;


	return 0;
}